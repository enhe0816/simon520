# test_auth.py
import pytest
import allure
from typing import Dict

@allure.feature("Authentication API")
class TestAuthentication:
    @allure.story("User Registration")
    @allure.title("Successful user registration")
    def test_register_success(self, api_client: ApiClient):
        """Test successful user registration"""
        user_data = TestDataGenerator.generate_user_data()
        
        with allure.step("Register new user"):
            response = api_client.post("/auth/register", json=user_data)
        
        with allure.step("Verify response"):
            assert response.status_code == 201, f"Expected 201, got {response.status_code}"
            assert "username" in response.json(), "Response should contain username"
            assert response.json()["username"] == user_data["username"]
            assert "password" not in response.json(), "Password should not be in response"

    @allure.story("User Registration")
    @allure.title("Register with missing required fields")
    @pytest.mark.parametrize("field", ["username", "password", "email", "phone"])
    def test_register_missing_field(self, api_client: ApiClient, field: str):
        """Test registration with missing required fields"""
        user_data = TestDataGenerator.generate_user_data()
        user_data.pop(field)
        
        response = api_client.post("/auth/register", json=user_data)
        
        assert response.status_code == 422, f"Expected 422, got {response.status_code}"
        assert "detail" in response.json(), "Error details should be in response"
        assert field in str(response.json()["detail"]), f"Error should mention missing {field}"

    @allure.story("User Login")
    @allure.title("Successful user login")
    def test_login_success(self, test_user: TestUser, api_client: ApiClient):
        """Test successful user login"""
        login_data = {
            "username": test_user.username,
            "password": test_user.password
        }
        
        response = api_client.post("/auth/login", json=login_data)
        
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        assert "access_token" in response.json(), "Response should contain access_token"
        assert len(response.json()["access_token"]) > 32, "Token should be sufficiently long"

    @allure.story("User Login")
    @allure.title("Login with invalid credentials")
    @pytest.mark.parametrize("invalid_creds", [
        {"username": "nonexistent", "password": "wrongpass"},
        {"username": "", "password": "wrongpass"},
        {"username": "testuser", "password": ""},
    ])
    def test_login_invalid_credentials(self, test_user: TestUser, api_client: ApiClient, invalid_creds: Dict):
        """Test login with invalid credentials"""
        response = api_client.post("/auth/login", json=invalid_creds)
        
        assert response.status_code == 422, f"Expected 422, got {response.status_code}"
        assert "detail" in response.json(), "Error details should be in response"

    @allure.story("User Registration")
    @allure.title("Register with invalid email format")
    def test_register_invalid_email(self, api_client: ApiClient, invalid_user_data):
        """Test registration with invalid email format"""
        response = api_client.post("/auth/register", json=invalid_user_data)
        
        assert response.status_code == 422, f"Expected 422, got {response.status_code}"
        assert "detail" in response.json(), "Error details should be in response"

# test_products.py
import pytest
import allure
from typing import List, Dict

@allure.feature("Products API")
class TestProducts:
    @allure.story("Product Listing")
    @allure.title("Get product list with pagination")
    def test_get_products_pagination(self, api_client: ApiClient):
        """Test product listing with pagination"""
        params = {"page": 2, "size": 5}
        
        with allure.step("Get paginated product list"):
            response = api_client.get("/products", params=params)
        
        with allure.step("Verify response"):
            assert response.status_code == 200, f"Expected 200, got {response.status_code}"
            products = response.json()
            assert isinstance(products, list), "Response should be a list"
            assert len(products) <= params["size"], f"Should return at most {params['size']} items"
            # Additional assertions would depend on actual API response structure

    @allure.story("Product Listing")
    @allure.title("Get product list with category filter")
    def test_get_products_by_category(self, api_client: ApiClient):
        """Test product listing filtered by category"""
        category_id = 1
        params = {"category_id": category_id}
        
        response = api_client.get("/products", params=params)
        
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        products = response.json()
        assert isinstance(products, list), "Response should be a list"
        # Additional assertions would verify products belong to specified category

    @allure.story("Product Listing")
    @allure.title("Get product list with invalid parameters")
    @pytest.mark.parametrize("invalid_params", [
        {"page": 0, "size": 5},
        {"page": 1, "size": 0},
        {"page": -1, "size": 5},
        {"page": 1, "size": 101},  # Assuming max size is 100
    ])
    def test_get_products_invalid_params(self, api_client: ApiClient, invalid_params: Dict):
        """Test product listing with invalid pagination parameters"""
        response = api_client.get("/products", params=invalid_params)
        
        assert response.status_code == 422, f"Expected 422, got {response.status_code}"

# test_cart.py
import pytest
import allure
from typing import Dict

@allure.feature("Cart API")
class TestCart:
    @allure.story("Cart Management")
    @allure.title("Add item to cart")
    def test_add_to_cart(self, authenticated_client: ApiClient, test_product: Dict):
        """Test adding item to cart"""
        cart_item = {
            "product_id": test_product["id"],
            "quantity": 2
        }
        
        # Get initial cart state
        initial_cart = authenticated_client.get("/cart")
        initial_items = initial_cart.json() if initial_cart.status_code == 200 else []
        
        # Add item to cart
        response = authenticated_client.post("/cart/add", json=cart_item)
        
        # Verify response
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        updated_cart = response.json()
        assert isinstance(updated_cart, list), "Cart should be a list of items"
        
        # Verify item was added
        found = False
        for item in updated_cart:
            if item["product_id"] == cart_item["product_id"]:
                assert item["quantity"] == cart_item["quantity"], "Quantity should match"
                found = True
                break
        assert found, "Added item should be in cart"

    @allure.story("Cart Management")
    @allure.title("Add invalid item to cart")
    @pytest.mark.parametrize("invalid_item", [
        {"product_id": 0, "quantity": 1},
        {"product_id": -1, "quantity": 1},
        {"product_id": 999999, "quantity": 1},  # Non-existent product
        {"product_id": 1, "quantity": 0},
        {"product_id": 1, "quantity": -1},
    ])
    def test_add_invalid_item_to_cart(self, authenticated_client: ApiClient, invalid_item: Dict):
        """Test adding invalid items to cart"""
        response = authenticated_client.post("/cart/add", json=invalid_item)
        
        assert response.status_code in (422, 404), f"Expected 422 or 404, got {response.status_code}"

    @allure.story("Cart Access")
    @allure.title("Get cart without authentication")
    def test_get_cart_unauthenticated(self, api_client: ApiClient):
        """Test accessing cart without authentication"""
        response = api_client.get("/cart")
        
        assert response.status_code == 401, f"Expected 401, got {response.status_code}"

# test_orders.py
import pytest
import allure
from typing import Dict

@allure.feature("Orders API")
class TestOrders:
    @allure.story("Order Creation")
    @allure.title("Create order with items in cart")
    def test_create_order(self, authenticated_client: ApiClient, test_address: Dict):
        """Test creating an order with items in cart"""
        # First ensure cart has items
        cart_item = {
            "product_id": 1,  # Assuming product exists
            "quantity": 1
        }
        authenticated_client.post("/cart/add", json=cart_item)
        
        # Create order
        order_data = {"address_id": test_address["id"]}
        response = authenticated_client.post("/orders/create", json=order_data)
        
        # Verify response
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        order = response.json()
        assert "id" in order, "Order should have an ID"
        assert "status" in order, "Order should have a status"
        assert order["status"] == "pending", "New order should be in pending status"
        assert "items" in order, "Order should contain items"
        assert len(order["items"]) > 0, "Order should contain at least one item"

    @allure.story("Order Creation")
    @allure.title("Create order with empty cart")
    def test_create_order_empty_cart(self, authenticated_client: ApiClient, test_address: Dict):
        """Test creating an order with empty cart should fail"""
        # Ensure cart is empty
        authenticated_client.delete("/cart")  # Assuming there's a cart clear endpoint
        
        # Attempt to create order
        order_data = {"address_id": test_address["id"]}
        response = authenticated_client.post("/orders/create", json=order_data)
        
        assert response.status_code == 400, f"Expected 400, got {response.status_code}"

    @allure.story("Order Creation")
    @allure.title("Create order without address")
    def test_create_order_no_address(self, authenticated_client: ApiClient):
        """Test creating an order without address should fail"""
        order_data = {}  # Missing address_id
        response = authenticated_client.post("/orders/create", json=order_data)
        
        assert response.status_code == 422, f"Expected 422, got {response.status_code}"