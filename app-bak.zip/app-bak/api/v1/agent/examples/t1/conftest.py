import pytest
import requests
from typing import Dict, Any, Generator
from mimesis import Person, Text, Internet, Finance, Datetime, Address, Numeric
import logging
import random
from dataclasses import dataclass

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Constants
BASE_URL = "http://localhost:8001"
DEFAULT_TIMEOUT = 10
MAX_RETRIES = 3

# Data Providers
person = Person('en')
text = Text('en')
internet = Internet()
finance = Finance()
datetime = Datetime()
address = Address()
number = Numeric()

@dataclass
class TestUser:
    username: str
    password: str
    email: str
    phone: str
    access_token: str = None

class TestDataGenerator:
    """Generates test data for API testing"""
    
    @staticmethod
    def generate_user_data() -> Dict[str, str]:
        """Generate random user registration data"""
        return {
            "username": person.username(mask='l_l_d', drange=(1900, 2021)),
            "password": f"P@ssw0rd{numbers.integer_number(1000, 9999)}",
            "email": internet.email(),
            "phone": person.telephone(mask='1##########')
        }
    
    @staticmethod
    def generate_product_data() -> Dict[str, Any]:
        """Generate random product data"""
        return {
            "name": text.word().capitalize() + " " + text.word(),
            "description": text.sentence(),
            "price": round(finance.price(minimum=1, maximum=1000), 2),
            "category_id": numbers.integer_number(1, 10)
        }
    
    @staticmethod
    def generate_cart_item_data(product_id: int) -> Dict[str, int]:
        """Generate cart item data"""
        return {
            "product_id": product_id,
            "quantity": numbers.integer_number(1, 5)
        }
    
    @staticmethod
    def generate_order_data(address_id: int) -> Dict[str, int]:
        """Generate order data"""
        return {
            "address_id": address_id
        }

class ApiClient:
    """Wrapper for API requests with logging and retry logic"""
    
    def __init__(self, base_url: str = BASE_URL):
        self.base_url = base_url
        self.session = requests.Session()
        self.session.headers.update({"Content-Type": "application/json"})
    
    def request(self, method: str, endpoint: str, **kwargs) -> requests.Response:
        """Make API request with retry logic"""
        url = f"{self.base_url}{endpoint}"
        timeout = kwargs.pop('timeout', DEFAULT_TIMEOUT)
        
        for attempt in range(1, MAX_RETRIES + 1):
            try:
                response = self.session.request(
                    method=method,
                    url=url,
                    timeout=timeout,
                    **kwargs
                )
                logger.info(f"Request: {method} {url} - Status: {response.status_code}")
                return response
            except requests.exceptions.RequestException as e:
                if attempt == MAX_RETRIES:
                    logger.error(f"Request failed after {MAX_RETRIES} attempts: {e}")
                    raise
                logger.warning(f"Attempt {attempt} failed, retrying...")
    
    def get(self, endpoint: str, **kwargs) -> requests.Response:
        return self.request('GET', endpoint, **kwargs)
    
    def post(self, endpoint: str, **kwargs) -> requests.Response:
        return self.request('POST', endpoint, **kwargs)
    
    def add_auth_header(self, token: str):
        """Add authorization header to session"""
        self.session.headers.update({"Authorization": f"Bearer {token}"})
    
    def clear_auth_header(self):
        """Remove authorization header from session"""
        self.session.headers.pop("Authorization", None)

@pytest.fixture(scope="session")
def api_client() -> Generator[ApiClient, None, None]:
    """Fixture providing API client"""
    client = ApiClient()
    yield client
    client.session.close()

@pytest.fixture(scope="module")
def test_user(api_client: ApiClient) -> Generator[TestUser, None, None]:
    """Fixture creating and cleaning up test user"""
    user_data = TestDataGenerator.generate_user_data()
    
    # Register user
    response = api_client.post("/auth/register", json=user_data)
    assert response.status_code == 201, f"Failed to register user: {response.text}"
    
    # Login to get token
    login_data = {
        "username": user_data["username"],
        "password": user_data["password"]
    }
    response = api_client.post("/auth/login", json=login_data)
    assert response.status_code == 200, f"Failed to login user: {response.text}"
    
    access_token = response.json().get("access_token")
    assert access_token, "No access token in login response"
    
    user = TestUser(**user_data, access_token=access_token)
    yield user
    
    # Cleanup - would need a user deletion endpoint
    # In real implementation, add cleanup logic here

@pytest.fixture
def authenticated_client(api_client: ApiClient, test_user: TestUser) -> ApiClient:
    """Fixture providing authenticated API client"""
    api_client.add_auth_header(test_user.access_token)
    yield api_client
    api_client.clear_auth_header()

@pytest.fixture
def product_data() -> Dict[str, Any]:
    """Fixture providing random product data"""
    return TestDataGenerator.generate_product_data()

@pytest.fixture
def test_product(authenticated_client: ApiClient, product_data: Dict[str, Any]) -> Dict[str, Any]:
    """Fixture creating and returning a test product"""
    # Assuming there's a product creation endpoint
    # In this example, we'll just return the generated data
    # In real implementation, create the product via API
    return product_data

@pytest.fixture
def cart_item_data(test_product: Dict[str, Any]) -> Dict[str, int]:
    """Fixture providing cart item data"""
    return TestDataGenerator.generate_cart_item_data(
        product_id=test_product.get("id", 1)  # Assuming product has ID
    )

@pytest.fixture
def address_data() -> Dict[str, Any]:
    """Fixture providing random address data"""
    return {
        "street": address.address(),
        "city": address.city(),
        "state": address.state(),
        "zip_code": address.postal_code(),
        "country": address.country()
    }

@pytest.fixture
def test_address(authenticated_client: ApiClient, address_data: Dict[str, Any]) -> Dict[str, Any]:
    """Fixture creating and returning a test address"""
    # Assuming there's an address creation endpoint
    # In this example, we'll just return the generated data with a mock ID
    # In real implementation, create the address via API
    return {"id": numbers.integer_number(1, 100), **address_data}

@pytest.fixture
def order_data(test_address: Dict[str, Any]) -> Dict[str, int]:
    """Fixture providing order data"""
    return TestDataGenerator.generate_order_data(
        address_id=test_address["id"]
    )

@pytest.fixture(scope="session", autouse=True)
def setup_teardown():
    """Global setup and teardown"""
    # Setup code if needed
    yield
    # Teardown code if needed

@pytest.fixture
def random_string() -> str:
    """Fixture providing random string"""
    return text.word()

@pytest.fixture
def random_email() -> str:
    """Fixture providing random email"""
    return internet.email()

@pytest.fixture
def random_phone() -> str:
    """Fixture providing random phone number"""
    return person.telephone(mask='1##########')

@pytest.fixture
def random_price() -> float:
    """Fixture providing random price"""
    return round(finance.price(minimum=1, maximum=1000), 2)

@pytest.fixture
def random_integer() -> int:
    """Fixture providing random integer"""
    return numbers.integer_number(1, 1000)

@pytest.fixture(params=[
    {"username": "", "password": "validPass123", "email": "test@example.com", "phone": "1234567890"},
    {"username": "testuser", "password": "", "email": "test@example.com", "phone": "1234567890"},
    {"username": "testuser", "password": "validPass123", "email": "", "phone": "1234567890"},
    {"username": "testuser", "password": "validPass123", "email": "test@example.com", "phone": ""},
    {"username": "testuser", "password": "validPass123", "email": "invalid-email", "phone": "1234567890"},
    {"username": "testuser", "password": "short", "email": "test@example.com", "phone": "1234567890"},
])
def invalid_user_data(request):
    """Fixture providing various invalid user data combinations"""
    return request.param

@pytest.fixture(params=[
    {"product_id": 0, "quantity": 1},
    {"product_id": -1, "quantity": 1},
    {"product_id": 1, "quantity": 0},
    {"product_id": 1, "quantity": -1},
    {"product_id": 999999, "quantity": 1},  # Non-existent product
])
def invalid_cart_item_data(request):
    """Fixture providing various invalid cart item data combinations"""
    return request.param