
import subprocess
import sys

try:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "matplotlib"])
    print("matplotlib安装成功")
except Exception as e:
    print(f"安装失败: {e}")
