# 导入必要的库
import random
from typing import Optional, List
import chainlit as cl  # Web UI框架
from chainlit.element import ElementBased
from chainlit.types import ThreadDict
from llama_index.core.base.llms.types import ChatMessage
from llama_index.core.chat_engine import SimpleChatEngine  # 简单对话引擎
from llama_index.core.chat_engine.types import ChatMode
from llama_index.core.memory import ChatMemoryBuffer  # 对话历史记忆管理
from rag.document import DocumentRAGV1, DocumentRAGV2, BaseRAG  # RAG检索增强生成系统
import chainlit.data as cl_data
from utils.logger import logger

# 初始化持久化存储层
# MinIO用于存储文件，PostgreSQL用于存储聊天记录
from utils import settings
from persistent.minio_storage_client import MinioStorageClient
from rag_system.persistent.postgresql_data_layer import PostGreSQLDataLayer
storage_client = MinioStorageClient()
cl_data._data_layer = PostGreSQLDataLayer(conninfo=settings.configuration.pg_connection_string, storage_provider=storage_client)


async def view_file(elements: List[ElementBased]):
    logger.info(f"开始处理文件预览，文件数量: {len(elements)}")
    files = []
    contents = []
    for element in elements:
        logger.info(f"处理文件: {element.name}, 类型: {element.mime}")
        if element.name.endswith((".pdf")):
            logger.debug(f"处理PDF文件: {element.name}")
            file = cl.Pdf(name=element.name, display="side", path=element.path)
        elif element.name.endswith((".png", ".jpg", ".jpeg", ".gif")):
            logger.debug(f"处理图片文件: {element.name}")
            file = cl.Image(name=element.name, display="side", path=element.path)
        elif element.name.endswith((".txt", ".md", ".py", ".json", ".yml", ".yaml", ".xml")):
            logger.debug(f"处理文本文件: {element.name}")
            try:
                with open(element.path, 'r', encoding='utf-8') as f:
                    content = f.read()
                file = cl.Text(name=element.name, content=content, display="side")
            except Exception as e:
                logger.error(f"读取文件失败: {element.name}, 错误: {str(e)}")
                file = cl.Text(name=element.name, content=f"无法读取文件内容: {str(e)}", display="side")
        else:
            logger.info(f"处理其他类型文件: {element.name}")
            file = cl.Text(
                name=element.name,
                content=f"文件类型: {element.mime}\n文件大小: {element.size}",
                display="side"
            )
        files.append(file)
        contents.append(element.name)

    if len(files) > 0:
        logger.info(f"发送文件预览消息，文件列表: {', '.join(contents)}")
        await cl.Message(content=f"查看文件：" + "，".join(contents), elements=files).send()


@cl.on_chat_start
async def start():
    logger.info("开始初始化对话")
    kb_name = cl.user_session.get("chat_profile")
    logger.info(f"当前知识库模式: {kb_name}")
    
    if kb_name is None or kb_name == "default" or kb_name == "大模型对话":
        logger.info("使用默认对话模式")
        memory = ChatMemoryBuffer.from_defaults(token_limit=1024)
        chat_engine = SimpleChatEngine.from_defaults(memory=memory)
    else:
        logger.info(f"加载知识库模式: {kb_name}")
        try:
            index = await DocumentRAGV1.load_remote_index(collection_name=kb_name)
            chat_engine = index.as_chat_engine(chat_mode=ChatMode.CONTEXT)
            logger.info(f"知识库 {kb_name} 加载成功")
        except Exception as e:
            logger.error(f"加载知识库失败: {str(e)}")
            raise

    cl.user_session.set("chat_engine", chat_engine)
    logger.info("对话初始化完成")

@cl.set_chat_profiles
async def chat_profile(current_user: cl.User):
    """设置对话配置
    配置可选的对话模式：
    1. 默认的大模型对话
    2. 基于已有知识库的对话
    """
    from utils.milvus import list_collections
    kb_list = list_collections()
    logger.info(f"获取到知识库列表: {kb_list}")
    
    profiles = [
        cl.ChatProfile(
            name="default",
            markdown_description=f"大模型对话",
            icon=f"/public/kbs/model.png",
        )
    ]
    for kb_name in kb_list:
        profiles.append(
            cl.ChatProfile(
                name=kb_name,
                markdown_description=f"{kb_name} 知识库",
                icon=f"/public/kbs/{random.randint(1, 3)}.jpg",
            )
        )
    logger.info(f"创建对话配置完成，共 {len(profiles)} 个配置")
    return profiles

@cl.set_starters
async def set_starters():
    """设置对话启动器
    预设一些常用的对话主题，方便用户快速开始对话
    """
    logger.info("初始化对话启动器")
    starters = [
        cl.Starter(
            label="大模型提高软件测试效率",
            message="详细介绍如何借助大语言模型提高软件测试效率。",
            icon="/public/apidog.svg",
        ),
        cl.Starter(
            label="自动化测试思路",
            message="详细描述一下接口及UI自动化测试的基本思路。",
            icon="/public/pulumi.svg",
        ),
        cl.Starter(
            label="性能测试分析及瓶颈定位思路",
            message="详细描述一下软件性能测试分析及瓶颈定位的核心思路。",
            icon="/public/godot_engine.svg",
        )
    ]
    logger.info(f"创建对话启动器完成，共 {len(starters)} 个预设主题")
    return starters

@cl.password_auth_callback
def auth_callback(username: str, password: str) -> Optional[cl.User]:
    """用户认证回调
    目前使用简单的用户名密码认证，可扩展对接第三方认证系统
    """
    logger.info(f"用户登录尝试: {username}")
    if (username, password) == ("admin", "admin"):
        logger.info(f"用户 {username} 登录成功")
        return cl.User(identifier="admin",
                       metadata={"role": "admin", "provider": "credentials"})
    else:
        logger.warning(f"用户 {username} 登录失败")
        return None

@cl.on_chat_resume
async def on_chat_resume(thread: ThreadDict):
    """恢复对话
    当用户恢复之前的对话时，重新加载对话历史
    """
    logger.info(f"恢复对话线程: {thread.get('id', 'unknown')}")
    chat_engine = SimpleChatEngine.from_defaults()
    for message in thread.get("steps", []):
        if message["type"] == "user_message":
            chat_engine.chat_history.append(ChatMessage(content=message["output"], role="user"))
        elif message["type"] == "assistant_message":
            chat_engine.chat_history.append(ChatMessage(content=message["output"], role="assistant"))
    cl.user_session.set("chat_engine", chat_engine)
    logger.info("对话历史恢复完成")


@cl.on_message
async def main(message: cl.Message):
    logger.info(f"收到新消息: {message.content[:100]}...")
    msg = cl.Message(content="", author="Assistant")
    chat_mode = cl.user_session.get("chat_profile", "大模型对话")
    logger.info(f"当前对话模式: {chat_mode}")

    chat_engine = cl.user_session.get("chat_engine")
    if chat_mode == "大模型对话" or chat_mode == "default":
        logger.info("处理默认模式文件上传")
        files = []
        for element in message.elements:
            if element.name.endswith((".pdf", ".txt", ".md", ".py", ".json", ".yml", ".yaml", ".xml")):
                logger.info(f"添加文件到处理列表: {element.name}")
                files.append(element.path)

        await view_file(message.elements)
        if len(files) > 0:
            logger.info(f"创建临时知识库，文件数量: {len(files)}")
            try:
                rag = DocumentRAGV1(files=files)
                # rag = DocumentRAGV2(files=files)
                index = await rag.create_local_index()
                chat_engine = index.as_chat_engine(chat_mode=ChatMode.CONTEXT, similarity_top_k=10)
                cl.user_session.set("chat_engine", chat_engine)
                logger.info("临时知识库创建成功")
            except Exception as e:
                logger.error(f"创建临时知识库失败: {str(e)}")
                raise

    logger.info("开始处理消息")
    try:
        logger.debug("准备调用 stream_chat")
        res = await cl.make_async(chat_engine.stream_chat)(message.content)
        if res is None:
            raise ValueError("stream_chat 返回为空")
        logger.debug(f"stream_chat 调用成功，返回类型: {type(res)}")
        logger.info("消息处理完成，开始流式输出")

        # 显示图片
        for source_node in res.source_nodes:
            if source_node.metadata.get("type") == "image":
                msg.elements.append(
                    cl.Image(path=source_node.metadata["image"],
                            name=source_node.metadata["source"],
                            display="inline"))

        for token in res.response_gen:
            await msg.stream_token(token)

        if not isinstance(chat_engine, SimpleChatEngine):
            logger.info("处理知识库引用")
            source_names = []
            for idx, node_with_score in enumerate(res.source_nodes):
                node = node_with_score.node
                source_name = f"source_{idx}"
                source_names.append(source_name)
                msg.elements.append(
                    cl.Text(content=node.get_text(),
                            name=source_name,
                            display="side")
                )
            await msg.stream_token(f"\n\n **数据来源**: {', '.join(source_names)}")
            logger.info(f"添加了 {len(source_names)} 个引用源")
    except Exception as e:
        logger.error(f"消息处理过程中出错: {str(e)}")
        raise
    finally:
        await msg.send()
        logger.info("消息发送完成")
  
