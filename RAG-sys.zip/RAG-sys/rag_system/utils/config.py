import os
from pydantic import BaseModel, Field

class Configuration(BaseModel):
    milvus_uri: str = Field(default=os.getenv("MILVUS_URI"), description="Milvus URI")
    embedding_model_dim: int = Field(default=1024, description="Embedding model dimension")
    llm_api_key: str = Field(default=os.getenv("LLM_API_KEY"), description="LLM API key")
    llm_api_base: str = Field(default=os.getenv("LLM_API_BASE"), description="LLM API base")
    llm_model_name: str = Field(default=os.getenv("LLM_MODEL_NAME"), description="LLM model name")
    local_embedding_model_name: str = Field(default=os.getenv("LOCAL_EMBEDDING_MODEL_NAME"), description="Local embedding model name")
    local_storage_embedding_model_name: str = Field(default=os.getenv("LOCAL_STORAGE_EMBEDDING_MODEL_NAME"), description="Local storage embedding model name")
    remote_embedding_model_name: str = Field(default=os.getenv("REMOTE_EMBEDDING_MODEL_NAME"), description="Remote embedding model name")
    remote_embedding_model_url: str = Field(default=os.getenv("REMOTE_EMBEDDING_MODEL_URL"), description="Remote embedding model URL")
    moonshot_api_key: str = Field(default=os.getenv("MOONSHOT_API_KEY"), description="Moonshot API key")
    pg_connection_string: str = Field(default=os.getenv("PG_CONNECTION_STRING"), description="Postgres connection string")

    minio_endpoint: str = Field(default=os.getenv("MINIO_ENDPOINT"), description="Minio endpoint")
    minio_access_key: str = Field(default=os.getenv("MINIO_ACCESS_KEY"), description="Minio access key")
    minio_secret_key: str = Field(default=os.getenv("MINIO_SECRET_KEY"), description="Minio secret key")
    minio_bucket_name: str = Field(default=os.getenv("MINIO_BUCKET_NAME"), description="Minio bucket name")

    deepseek_api_key: str = Field(default=os.getenv("DEEPSEEK_API_KEY"), description="Deepseek API key")
    deepseek_api_base: str = Field(default=os.getenv("DEEPSEEK_API_BASE"), description="Deepseek API base")
    deepseek_model_name: str = Field(default=os.getenv("DEEPSEEK_MODEL_NAME"), description="Deepseek model name")

    use_rerank: bool = Field(default=os.getenv("USE_RERANK", "false").lower() == "true", description="Whether to use rerank")
    rerank_model: str = Field(default=os.getenv("RERANK_MODEL", "cross-encoder/ms-marco-MiniLM-L-6-v2"), description="Rerank model name")
    rerank_top_n: int = Field(default=int(os.getenv("RERANK_TOP_N", "2")), description="Number of documents to keep after rerank")
    recall_top_k: int = Field(default=int(os.getenv("RECALL_TOP_K", "10")), description="Number of documents to recall before rerank")

    use_hybrid_search: bool = Field(default=os.getenv("USE_HYBRID_SEARCH", "false").lower() == "true", description="Whether to use hybrid search")
    vector_top_k: int = Field(default=int(os.getenv("VECTOR_TOP_K", "5")), description="Top k for vector search")
    bm25_top_k: int = Field(default=int(os.getenv("BM25_TOP_K", "5")), description="Top k for BM25 search")
    embed_batch_size: int = Field(default=int(os.getenv("EMBED_BATCH_SIZE", "32")), description="Batch size for embedding generation")
    use_async: bool = Field(default=os.getenv("USE_ASYNC", "true").lower() == "true", description="Whether to use async processing")

    chunk_size: int = Field(default=int(os.getenv("CHUNK_SIZE", "512")), description="The token chunk size for each chunk")
    chunk_overlap: int = Field(default=int(os.getenv("CHUNK_OVERLAP", "200")), description="The token overlap of each chunk")

    vllm_api_key: str = Field(default=os.getenv("VLLM_API_KEY"), description="VLLM API key")
    vllm_base_url: str = Field(default=os.getenv("VLLM_BASE_URL"), description="VLLM base URL")
    vllm_model_name: str = Field(default=os.getenv("VLLM_MODEL_NAME"), description="VLLM model name")

    
