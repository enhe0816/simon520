import os.path

from chainlit.utils import mount_chainlit
from dotenv import load_dotenv
from fastapi import FastAPI, UploadFile, Form
from fastapi.responses import HTMLResponse
load_dotenv()
from rag.document import DocumentRAGV1
from utils.r import R
app = FastAPI()

@app.post("/files/")
async def create_upload_files(files: list[UploadFile], collection_name: str = Form()):
    file_list = []
    for file in files:
        file_path = os.path.join("documents", os.path.basename(file.filename))
        with open(file_path, "wb+") as f:
            f.write(await file.read())
            file_list.append(file_path)
    rag = DocumentRAGV1(files=file_list)
    await rag.create_remote_index(collection_name=collection_name)
    return R.ok("index success")


@app.get("/")
async def main():
    content = """
    <!DOCTYPE html>
    <html lang="zh">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>知识库文件上传</title>
        <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    </head>
    <body class="bg-gray-100 h-screen flex items-center justify-center">
        <div class="bg-white p-8 rounded-lg shadow-lg max-w-md w-full">
            <h1 class="text-2xl font-bold text-center mb-6 text-gray-800">知识库文件上传</h1>
            <form action="/files/" method="post" enctype="multipart/form-data" class="space-y-6">
                <div class="space-y-2">
                    <label class="block text-sm font-medium text-gray-700">
                        选择文件
                    </label>
                    <div class="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
                        <div class="space-y-1 text-center">
                            <svg class="mx-auto h-12 w-12 text-gray-400" stroke="currentColor" fill="none" viewBox="0 0 48 48">
                                <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                            </svg>
                            <div class="flex text-sm text-gray-600">
                                <label class="relative cursor-pointer bg-white rounded-md font-medium text-indigo-600 hover:text-indigo-500">
                                    <span>上传文件</span>
                                    <input name="files" type="file" multiple class="sr-only" onchange="updateFileList(this)">
                                </label>
                                <p class="pl-1">或拖拽文件到这里</p>
                            </div>
                            <p class="text-xs text-gray-500">支持多个文件上传</p>
                            <div id="fileList" class="mt-2 text-sm text-gray-500"></div>
                        </div>
                    </div>
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700">
                        知识库名称
                    </label>
                    <input type="text" name="collection_name" required
                        class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                        placeholder="请输入知识库名称（英文）">
                </div>
                
                <button type="submit"
                    class="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                    开始上传
                </button>
            </form>
        </div>
        
        <script>
        function updateFileList(input) {
            const fileList = document.getElementById('fileList');
            fileList.innerHTML = '';
            if (input.files.length > 0) {
                const list = document.createElement('ul');
                list.className = 'list-disc pl-5';
                Array.from(input.files).forEach(file => {
                    const li = document.createElement('li');
                    li.textContent = file.name;
                    list.appendChild(li);
                });
                fileList.appendChild(list);
            }
        }
        
        // 拖拽上传支持
        const dropZone = document.querySelector('form');
        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            dropZone.addEventListener(eventName, preventDefaults, false);
        });

        function preventDefaults (e) {
            e.preventDefault();
            e.stopPropagation();
        }

        dropZone.addEventListener('drop', handleDrop, false);

        function handleDrop(e) {
            const dt = e.dataTransfer;
            const files = dt.files;
            const fileInput = document.querySelector('input[type="file"]');
            fileInput.files = files;
            updateFileList(fileInput);
        }
        </script>
    </body>
    </html>
    """
    return HTMLResponse(content=content)

mount_chainlit(app=app, target="ui.py", path="/chainlit")
# 启动fastapi命令： uvicorn main:app --host 0.0.0.0 --port 80
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=80)
