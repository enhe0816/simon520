# 基础依赖
from abc import abstractmethod

# LlamaIndex 核心组件
from llama_index.core import (
    VectorStoreIndex,
    load_index_from_storage,
    StorageContext
)
from llama_index.core.indices.base import BaseIndex
from llama_index.core.node_parser import SentenceSplitter
from llama_index.core.postprocessor import SentenceTransformerRerank

# Milvus 向量存储
from llama_index.vector_stores.milvus import MilvusVectorStore

# 项目配置
import rag_system.utils.settings as settings
from utils.logger import logger

from llama_index.core.storage.storage_context import DEFAULT_PERSIST_DIR

class BaseRAG:
    def __init__(self, files: list[str]):
        self.files = files
        self.use_rerank = settings.configuration.use_rerank
        self.rerank_model = settings.configuration.rerank_model
        self.rerank_top_n = settings.configuration.rerank_top_n
        self.recall_top_k = settings.configuration.recall_top_k
        # 混合检索配置
        self.use_hybrid_search = settings.configuration.use_hybrid_search
        self.vector_top_k = settings.configuration.vector_top_k
        self.bm25_top_k = settings.configuration.bm25_top_k
    @abstractmethod
    async def load_data(self):
        """加载数据"""

    def _apply_search_strategy(self, index: BaseIndex) -> BaseIndex:
        """应用检索策略（混合检索和重排序）"""
        if self.use_hybrid_search:
            logger.info("使用混合检索策略")
            # 使用 Milvus 原生的混合搜索
            index.as_query_engine(
                similarity_top_k=self.recall_top_k,
                vector_store_query_mode="hybrid",  # 启用 Milvus 原生混合搜索
            )
            
            if self.use_rerank:
                logger.info("使用重排序模型")
                rerank = SentenceTransformerRerank(
                    model=self.rerank_model,
                    top_n=self.rerank_top_n
                )
                index.node_postprocessors = [rerank]
        elif self.use_rerank:
            logger.info("使用重排序模型")
            rerank = SentenceTransformerRerank(
                model=self.rerank_model,
                top_n=self.rerank_top_n
            )
            index.node_postprocessors = [rerank]
        else:
            logger.info("不使用混合检索策略和重排序模型")
        
        return index
    

    async def create_local_index(self, persist_dir=DEFAULT_PERSIST_DIR) -> BaseIndex:
        """
        创建本地索引，该函数是数据嵌入的重点优化模块
        入库优化：数据清洗优化--》分块优化
        参考LLmaindex的分块策略：https://docs.llamaindex.ai/en/stable/api_reference/node_parsers/
        :param persist_dir: 本地持久化路径
        :return: BaseIndex
        """
        # 加载数据
        data = await self.load_data()
        # 创建一个句子分割器
        node_splitter = SentenceSplitter.from_defaults(separator="。", chunk_size=settings.configuration.chunk_size,
            chunk_overlap=settings.configuration.chunk_overlap)
        # 从文档中获取节点
        nodes = node_splitter.get_nodes_from_documents(data, show_progress=True, embed_batch_size=settings.configuration.embed_batch_size,
            use_async=settings.configuration.use_async)
        # 创建向量存储索引，该部分需要用到嵌入模型，当前嵌入模型的设置在utils/settings.py中

        index = VectorStoreIndex(nodes, show_progress=True)
        # index = VectorStoreIndex.from_documents(data, show_progress=True)
        index = self._apply_search_strategy(index)
        
        # 对向量数据库做持久化
        index.storage_context.persist(persist_dir=persist_dir)
        # 返回创建的索引
        return index

    async def create_remote_index(self, collection_name="default") -> BaseIndex:
        """
        创建远程索引
        :param collection_name: 不能包含中文
        :return:
        """
        # 加载数据
        data = await self.load_data()
        # 创建一个句子分割器
        node_parser = SentenceSplitter.from_defaults(separator="。", chunk_size=settings.configuration.chunk_size,
            chunk_overlap=settings.configuration.chunk_overlap)
        # 从文档中获取节点
        nodes = node_parser.get_nodes_from_documents(data,show_progress=True, embed_batch_size=settings.configuration.embed_batch_size,
            use_async=settings.configuration.use_async)
        # 创建向量存储索引
        vector_store = MilvusVectorStore(
            uri=settings.configuration.milvus_uri,
            collection_name=collection_name, dim=settings.configuration.embedding_model_dim, overwrite=True
        )
        storage_context = StorageContext.from_defaults(vector_store=vector_store)
        index = VectorStoreIndex(nodes, storage_context=storage_context,show_progress=True)
        index = self._apply_search_strategy(index)
        return index

    @staticmethod
    async def load_remote_index(collection_name="default") -> BaseIndex:
        vector_store = MilvusVectorStore(
            uri=settings.configuration.milvus_uri,
            collection_name=collection_name, dim=settings.configuration.embedding_model_dim, overwrite=False
        )
        return VectorStoreIndex.from_vector_store(vector_store=vector_store)

    @staticmethod
    async def load_local_index(persist_dir=DEFAULT_PERSIST_DIR) -> BaseIndex:
        return load_index_from_storage(
            StorageContext.from_defaults(persist_dir=persist_dir)
        )

