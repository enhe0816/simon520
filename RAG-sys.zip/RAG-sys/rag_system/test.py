# from huggingface_hub import snapshot_download

# # 下载到指定目录
# model_path = snapshot_download(
#     # repo_id="BAAI/bge-reranker-base",
#     repo_id="OpenGVLab/InternVL2-4B",
#     local_dir="D:\\models",
#     ignore_patterns=["*.md", "*.txt"]
# )

# from llama_index.embeddings.ollama import OllamaEmbedding

# # 创建 embedding 模型实例
# embed_model = OllamaEmbedding(
#     model_name="bge-m3:latest",  # 或其他模型名称
#     base_url="http://localhost:11434"
# )

# # 测试一个简单的文本
# test_text = "测试文本"
# embedding = embed_model.get_text_embedding(test_text)
# print(f"向量维度: {len(embedding)}")

import fitz  # PyMuPDF

def extract_pdf_pages(input_pdf_path, output_pdf_path, pages_to_keep):
    """
    从PDF中提取指定页面并生成新的PDF文件
    
    :param input_pdf_path: 输入PDF文件路径
    :param output_pdf_path: 输出PDF文件路径
    :param pages_to_keep: 要保留的页面序号列表（从1开始）
    """
    # 打开源PDF文件
    src_doc = fitz.open(input_pdf_path)
    
    # 创建新的PDF文档
    dst_doc = fitz.open()
    
    # 复制指定页面到新文档
    for page_num in pages_to_keep:
        # PDF页面索引从0开始
        dst_doc.insert_pdf(src_doc, from_page=page_num-1, to_page=page_num-1)
    
    # 保存新文档
    dst_doc.save(output_pdf_path)
    
    # 关闭文档
    src_doc.close()
    dst_doc.close()

if __name__ == "__main__":
    # 设置文件路径
    input_pdf = r"D:\ai_testing_002_20250215\examples_20250215\data\account.pdf"  # 替换为你的PDF文件路径
    output_pdf = r"D:\ai_testing_002_20250215\examples_20250215\data\account_2pages.pdf"  # 输出PDF的路径
    pages_to_keep = [1, 11]  # 要保留的页面序号，这里选择第1页和第5页
    
    extract_pdf_pages(input_pdf, output_pdf, pages_to_keep)