from openai import OpenAI
import os
from dotenv import load_dotenv


 
# 加载.env文件
load_dotenv()

print(os.getenv("MODEL_API_KEY"))
print(os.getenv("MODEL_BASE_URL"))

  # 初始化AI客户端
client = OpenAI(
    api_key= os.getenv("MODEL_API_KEY"),
    base_url= os.getenv("MODEL_BASE_URL")
)

prompt = "你好,python好学吗，返回100个以内的字"

response = client.chat.completions.create(
        model="glm-4-plus",  
        messages=[    
        {"role": "system", "content": "You are a helpful assistant"},
        {"role": "user", "content": prompt}
        ],
        top_p=0.7,
        temperature=0.9
    ) 

print(response.choices[0].message.content)
 