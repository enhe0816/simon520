
# 定一个大模型配置字典，可以依据大模型名称，切换不同的大模型参数配置
MODEL_CONFIG = {
    "glm-4-plus": {
        "model": "glm-4-plus",
        "api_key": "your api key",
        "api_base": "https://api.glm.com/v1"
    },
    "moonshot-v1-8k": {
        "model": "moonshot-v1-8k",
        "api_key": "your api key",
        "api_base": "https://api.moonshot.com/v1"
    },
    "openai": {
        "model": "llama3-8b-8192",
        "api_key": "your api key",
        "api_base": "https://api.llama.com/v1"
    },
    "deepseek": {
        "model": "deepseek-coder",
        "api_key": "your api key",
        "api_base": "https://api.deepseek.com/v1"
    },
    "qwen": {
        "model": "qwen-coder",
        "api_key": "your api key",
        "api_base": "https://api.qwen.com/v1"
    },
    "claude3.7": {
        "model": "claude-3-7-sonnet",
        "api_key": "your api key",
        "api_base": "https://api.anthropic.com/v1"
    }
}