

# 获取sqlite数据库message表的全部数据，并打印出来
import sqlite3

conn = sqlite3.connect('chat_history.db')

cursor = conn.cursor()
# 执行 SQL查询
# cursor.execute("SELECT * FROM messages")
# rows = cursor.fetchall()
# for row in rows:
#     print(row)

# 更新数据
# sql =" update messages set content = '正式员工的餐补是每月500元。' where id = 10 "
# cursor.execute(sql)
# conn.commit()


#删除数据
sql = "delete from messages where id = 9"
cursor.execute(sql)
conn.commit()


#  CREATE TABLE IF NOT EXISTS messages (
#         id INTEGER PRIMARY KEY AUTOINCREMENT,
#         session_id TEXT,
#         role TEXT,
#         content TEXT,
#         created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
#         FOREIGN KEY (session_id) REFERENCES chat_sessions (id)
#     )
# 插入数据
sql = "insert into messages (session_id, role, content) values ('d2f05057-7eb6-415d-8ab9-00b6cb9fbc5d', 'user', '正式员工的餐补是多少？')"
cursor.execute(sql)
conn.commit()


# CRUD

C = Create  # 创建 insert
R = Read    # 读取 select
U = Update  # 更新 update
D = Delete  # 删除 delete

# 关闭数据库连接
conn.close()
